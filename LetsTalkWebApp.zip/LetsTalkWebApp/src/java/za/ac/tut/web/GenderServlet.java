/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package za.ac.tut.web;

import jakarta.servlet.RequestDispatcher;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import za.ac.tut.model.ConversationInterface;
import za.ac.tut.model.ConversationManager;

/**
 *
 * @author Alex
 */
@WebServlet(name = "GenderServlet", urlPatterns = {"/GenderServlet.do"})
public class GenderServlet extends HttpServlet {


    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(true);
        String gender = request.getParameter("gender");
        
        ConversationInterface ci = new ConversationManager();
        
        String title = ci.generateTitle(gender);
        session.setAttribute("title", title);
        
        RequestDispatcher disp = request.getRequestDispatcher("gender_outcome.jsp");
        disp.forward(request, response);
    }
    
}
