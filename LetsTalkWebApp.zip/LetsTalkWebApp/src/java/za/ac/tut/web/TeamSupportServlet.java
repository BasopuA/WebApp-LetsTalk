/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package za.ac.tut.web;

import jakarta.servlet.RequestDispatcher;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import za.ac.tut.model.ConversationInterface;
import za.ac.tut.model.ConversationManager;

/**
 *
 * @author Alex
 */
public class TeamSupportServlet extends HttpServlet {


    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(true);
        String teamSupported = request.getParameter("team_supported");
        
        ConversationInterface ci = new ConversationManager();
        String comment = ci.generateComment(teamSupported);
        session.setAttribute("comment", comment);
        
        RequestDispatcher disp = request.getRequestDispatcher("advice.jsp");
        disp.forward(request, response);
    }
    

   
}
