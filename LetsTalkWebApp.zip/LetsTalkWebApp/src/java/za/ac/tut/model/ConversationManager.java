/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package za.ac.tut.model;

/**
 *
 * @author Alex
 */
public class ConversationManager implements ConversationInterface{

    @Override
    public String generateTitle(String gender) {
        String title = "Mr.";
        if(gender.equals("Female"))
        {
            title = "Ms.";
        }
        return title;
    }

    @Override
    public String generateComment(String supportedTeam) {
        String comment = "Supporting teams other than Pirates is a bad choice. You will be forever miserable in life";
        if(supportedTeam.equals("Pirates"))
        {
            comment = "Supporing Pirates is a good choice. You will be forever happy in life";
        }
        return comment;
    }
    
}
